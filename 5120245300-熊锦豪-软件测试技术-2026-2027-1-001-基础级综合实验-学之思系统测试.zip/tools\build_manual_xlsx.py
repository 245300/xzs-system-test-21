# -*- coding: utf-8 -*-
"""生成学之思系统手工测试记录 Excel（含内嵌截图）。

数据全部来自本轮真实执行记录：24 条手工用例、6 个缺陷、24 张功能截图、
2 张界面与兼容性截图（截图说明页共 26 张内嵌）。
"""
import os
import glob
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image as XLImage
from PIL import Image as PILImage

ROOT = r"C:\5120245300"
SHOT = os.path.join(ROOT, "doc", "screenshots")
OUT = os.path.join(ROOT, "doc", "学之思系统手工测试记录.xlsx")

HEAD_FILL = PatternFill("solid", fgColor="1F4E79")
HEAD_FONT = Font(color="FFFFFF", bold=True, size=11)
TITLE_FONT = Font(bold=True, size=14)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)

PASS_FILL = PatternFill("solid", fgColor="E2EFDA")
FAIL_FILL = PatternFill("solid", fgColor="FCE4E4")


def put_head(ws, row, heads, widths=None):
    for i, h in enumerate(heads, 1):
        c = ws.cell(row=row, column=i, value=h)
        c.fill = HEAD_FILL
        c.font = HEAD_FONT
        c.alignment = CENTER
        c.border = BORDER
    if widths:
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def fill_rows(ws, start_row, rows, center_cols=()):
    for r, row in enumerate(rows, start_row):
        for i, v in enumerate(row, 1):
            c = ws.cell(row=r, column=i, value=v)
            c.border = BORDER
            c.alignment = CENTER if i in center_cols else WRAP


# ---------------------------------------------------------------- 用例数据
CASES = [
    # 编号, 模块, 标题, 优先级, 类型, 前置条件, 步骤, 测试数据, 预期结果, 设计方法
    ("TC-A01", "登录注册", "学生端登录页正确加载并展示输入项", "高", "正常",
     "学之思服务已启动（8065）", "1. 浏览器访问学生端地址；2. 观察页面元素",
     "URL: http://127.0.0.1:8065/student/index.html",
     "显示用户名、密码输入框、登录按钮与“忘记密码/注册”入口", "场景法"),
    ("TC-A02", "登录注册", "正确账号密码登录成功进入首页", "高", "正常",
     "登录页已打开", "1. 输入用户名；2. 输入密码；3. 点击“登录”",
     "student / 123456", "跳转到学生首页，展示任务中心与固定/时段试卷", "等价类划分"),
    ("TC-A03", "登录注册", "错误密码登录被拒绝", "高", "异常",
     "登录页已打开", "1. 输入正确用户名；2. 输入错误密码；3. 点击“登录”",
     "student / wrong123", "提示“用户名或密码错误”，停留在登录页", "错误推测法"),
    ("TC-A04", "登录注册", "空用户名登录被拒绝", "中", "异常",
     "登录页已打开", "1. 用户名留空；2. 输入密码；3. 点击“登录”",
     "（空） / 123456", "提示“用户名或密码错误”，不进入首页", "边界值分析"),
    ("TC-A05", "登录注册", "已登录状态直接访问登录地址", "低", "异常",
     "已用 student 登录成功", "1. 地址栏直接访问 #/login；2. 观察页面",
     "已登录会话", "页面正常加载，允许停留登录页并可重新登录，不出现白屏或报错", "错误推测法"),

    ("TC-B01", "试卷中心与答题", "固定试卷列表正确展示", "高", "正常",
     "已登录学生端", "1. 点击顶部“试卷中心”；2. 观察“固定试卷”页签列表",
     "科目：语文", "列出固定试卷（一年级语文基础测试）及“开始答题”入口", "场景法"),
    ("TC-B02", "试卷中心与答题", "点击开始答题进入答题页", "高", "正常",
     "试卷中心已打开", "1. 点击目标试卷的“开始答题”", "一年级语文基础测试",
     "新标签页打开答题页，显示 10 道单选题与剩余时间", "场景法"),
    ("TC-B03", "试卷中心与答题", "未作答直接提交的校验", "中", "异常",
     "已进入答题页且未选择任何选项", "1. 不选择任何选项；2. 直接点击“提交”",
     "全部题目未作答", "提示尚有题目未作答并二次确认后才允许交卷", "错误推测法"),
    ("TC-B04", "试卷中心与答题", "完成全部作答提交后显示得分", "高", "正常",
     "已进入答题页", "1. 依次作答 10 题；2. 点击“提交”", "答案：B B B B A A A B C A",
     "弹出“考试结果”，试卷得分 50 分（满分 50）", "场景法"),
    ("TC-B05", "试卷中心与答题", "时段试卷分类空列表提示", "低", "正常",
     "试卷中心已打开", "1. 切换到“时段试卷”页签", "无时段试卷数据",
     "列表显示“暂无数据”，不报错", "边界值分析"),

    ("TC-C01", "考试记录与错题本", "考试记录列表展示", "高", "正常",
     "已登录且存在答卷记录", "1. 点击顶部“考试记录”", "学生已有 3 次答卷",
     "列表展示序号、名称、学科、状态、做题时间与“查看试卷”", "场景法"),
    ("TC-C02", "考试记录与错题本", "查看试卷详情与判分明细", "中", "正常",
     "考试记录列表已打开", "1. 点击某条记录的“查看试卷”", "最近一次答卷",
     "展示系统判分、最终得分、正确题数、总题数与用时", "场景法"),
    ("TC-C03", "考试记录与错题本", "错题本展示错题与正确答案", "中", "正常",
     "已登录且存在错题", "1. 点击顶部“错题本”；2. 点击任一条错题", "10 道错题",
     "列表展示题干/题型/学科/做题时间，右侧展示选项、结果、分数、解析与正确答案", "场景法"),
    ("TC-C04", "考试记录与错题本", "错题本分页切换", "低", "正常",
     "错题本已打开且存在 2 页数据", "1. 点击分页第 2 页", "第 2 页数据",
     "切换到第 2 页，展示剩余错题", "边界值分析"),
    ("TC-C05", "考试记录与错题本", "访问不存在的答卷详情页", "中", "异常",
     "已登录学生端", "1. 地址栏直接访问 #/read?id=666666（不存在的答卷 ID）；2. 观察页面表现",
     "答卷 ID 666666（不存在）",
     "提示“答卷不存在或无权限查看”，并可返回考试记录列表", "错误推测法"),

    ("TC-D01", "个人中心", "个人中心信息展示与用户动态", "高", "正常",
     "已登录学生端", "1. 点击右上角头像；2. 点击“个人中心”", "student",
     "展示用户名、姓名、年级、注册时间与用户动态列表", "场景法"),
    ("TC-D02", "个人中心", "合法资料修改保存成功", "高", "正常",
     "已进入个人中心-个人资料修改", "1. 修改年龄为 19；2. 点击“更新”",
     "年龄 19，其余保持不变", "提示“成功”，表单保留新值", "等价类划分"),
    ("TC-D03", "个人中心", "手机号位数校验（9 位）", "中", "异常",
     "已进入资料修改页", "1. 手机号输入 9 位数字；2. 点击“更新”", "138001380",
     "提示手机号必须 11 位并阻止保存", "边界值分析"),
    ("TC-D04", "个人中心", "年龄取值范围校验（121）", "中", "异常",
     "已进入资料修改页", "1. 年龄输入 121；2. 点击“更新”", "121",
     "提示年龄超出 1-120 范围并阻止保存", "边界值分析"),
    ("TC-D05", "个人中心", "真实姓名留空提交", "中", "异常",
     "已进入资料修改页", "1. 清空真实姓名；2. 点击“更新”", "（空）",
     "提示真实姓名不能为空并阻止保存", "错误推测法"),

    ("TC-E01", "消息中心", "消息列表展示", "中", "正常",
     "已登录学生端", "1. 点击头像；2. 点击“消息中心”", "学生已有 8 条消息",
     "列表展示消息标题与已读/未读状态，分页正常", "场景法"),
    ("TC-E02", "消息中心", "消息详情阅读", "中", "正常",
     "消息中心已打开", "1. 点击任一条消息", "已读消息",
     "右侧展示发送人、发送时间与发送内容", "场景法"),
    ("TC-E03", "消息中心", "未读消息阅读后角标变化", "低", "正常",
     "消息中心已打开，存在未读消息", "1. 记录未读角标；2. 点击一条未读消息",
     "未读 6 条", "角标由 6 变为 5，该条状态变为已读", "边界值分析"),
    ("TC-E04", "消息中心", "未登录直接访问消息中心", "中", "异常",
     "未登录（全新会话，无 token）", "1. 新开无痕窗口；2. 地址栏直接访问 #/user/message；3. 观察页面",
     "无登录态", "重定向到登录页，不展示任何消息内容", "错误推测法"),
]

# 编号, 实际结果, 状态, 执行时间, 执行人, 环境, 截图
EXEC = {
    "TC-A01": ("登录页正常渲染，用户名/密码输入框、登录按钮、注册入口齐全", "通过", "2026-11-13 20:09", "熊锦豪", "Chrome 157 / 8065", "manual/TC-A01-登录页展示.png"),
    "TC-A02": ("输入 student/123456 后跳转 #/index，首页展示任务中心与试卷", "通过", "2026-11-13 20:10", "熊锦豪", "Chrome 157 / 8065", "manual/TC-A02-正确登录进入首页.png"),
    "TC-A03": ("弹出“用户名或密码错误”，URL 仍为 #/login", "通过", "2026-11-13 20:10", "熊锦豪", "Chrome 157 / 8065", "manual/TC-A03-错误密码被拒绝.png"),
    "TC-A04": ("用户名留空点击登录，前端未拦截，请求返回“用户名或密码错误”，未进入首页", "通过", "2026-11-13 20:10", "熊锦豪", "Chrome 157 / 8065", "manual/TC-A04-空用户名被拒绝.png"),
    "TC-A05": ("已登录后访问 #/login 停留在登录页，可正常重新登录，页面无报错", "通过", "2026-11-13 20:10", "熊锦豪", "Chrome 157 / 8065", "manual/TC-A05-已登录访问登录页.png"),

    "TC-B01": ("固定试卷页签仅 1 条：一年级语文基础测试，含“开始答题”", "通过", "2026-11-13 20:11", "熊锦豪", "Chrome 157 / 8065", "manual/TC-B01-试卷中心列表.png"),
    "TC-B02": ("新标签页打开 #/do?id=1，显示 10 道单选题、剩余时间 29:40", "通过", "2026-11-13 20:11", "熊锦豪", "Chrome 157 / 8065", "manual/TC-B02-进入答题页.png"),
    "TC-B03": ("未作答直接提交，无任何确认提示，直接弹出“试卷得分：0分”", "失败", "2026-11-13 20:12", "熊锦豪", "Chrome 157 / 8065", "manual/TC-B03-未作答直接提交.png"),
    "TC-B04": ("10 题全部作答后提交，弹出“试卷得分：50分”（满分 50）", "通过", "2026-11-13 20:12", "熊锦豪", "Chrome 157 / 8065", "manual/TC-B04-提交后显示得分.png"),
    "TC-B05": ("时段试卷页签显示“暂无数据”，页面无报错", "通过", "2026-11-13 20:13", "熊锦豪", "Chrome 157 / 8065", "manual/TC-B05-时段试卷空列表.png"),

    "TC-C01": ("列表展示 3 条答卷记录，状态均为“完成”，含做题时间", "通过", "2026-11-13 20:13", "熊锦豪", "Chrome 157 / 8065", "manual/TC-C01-考试记录列表.png"),
    "TC-C02": ("打开 #/read?id=3，展示系统判分 50、最终得分 50、正确题数 10/10、用时 3 秒", "通过", "2026-11-13 20:13", "熊锦豪", "Chrome 157 / 8065", "manual/TC-C02-查看试卷详情.png"),
    "TC-C03": ("错题本展示 10 道错题，右侧面板含结果、分数、难度、解析与正确答案 A", "通过", "2026-11-13 20:13", "熊锦豪", "Chrome 157 / 8065", "manual/TC-C03-错题本展示.png"),
    "TC-C04": ("点击第 2 页后展示剩余 1 条错题，分页功能正常", "通过", "2026-11-13 20:14", "熊锦豪", "Chrome 157 / 8065", "manual/TC-C04-错题本分页切换.png"),
    "TC-C05": ("顶部仅显示“试卷得分：0　试卷耗时：0秒”，内容区空白并一直转圈，弹出“系统内部错误”", "失败", "2026-11-15 13:17", "熊锦豪", "Chrome 157 / 8065", "manual/TC-C05-不存在的答卷报错.png"),

    "TC-D01": ("展示 student、姓名学生、年级一年级、注册时间与用户动态", "通过", "2026-11-13 20:15", "熊锦豪", "Chrome 157 / 8065", "manual/TC-D01-个人中心信息展示.png"),
    "TC-D02": ("修改年龄为 19 后点击更新，提示“成功”，表单回读为 19", "通过", "2026-11-13 20:16", "熊锦豪", "Chrome 157 / 8065", "manual/TC-D02-合法资料保存成功.png"),
    "TC-D03": ("输入 9 位手机号 138001380 点击更新，提示“成功”且保存成功", "失败", "2026-11-13 20:17", "熊锦豪", "Chrome 157 / 8065", "manual/TC-D03-手机号9位仍保存.png"),
    "TC-D04": ("年龄输入 121 点击更新，提示“成功”，数据库记录为 121", "失败", "2026-11-13 20:18", "熊锦豪", "Chrome 157 / 8065", "manual/TC-D04-年龄121仍保存.png"),
    "TC-D05": ("真实姓名留空点击更新，无任何提示，数据库未变更", "失败", "2026-11-13 20:19", "熊锦豪", "Chrome 157 / 8065", "manual/TC-D05-真实姓名留空仍保存.png"),

    "TC-E01": ("消息中心展示 8 条消息（标题+已读/未读），分页正常", "通过", "2026-11-13 20:20", "熊锦豪", "Chrome 157 / 8065", "manual/TC-E01-消息中心列表.png"),
    "TC-E02": ("点击消息后右侧展示发送人 admin、发送时间与发送内容", "通过", "2026-11-13 20:20", "熊锦豪", "Chrome 157 / 8065", "manual/TC-E02-消息详情阅读.png"),
    "TC-E03": ("点击未读消息后角标由 6 变为 5，该条状态变为已读", "通过", "2026-11-13 20:21", "熊锦豪", "Chrome 157 / 8065", "manual/TC-E03-未读消息阅读后角标变化.png"),
    "TC-E04": ("自动跳转 #/login 并提示“用户未登录”，消息内容未展示", "通过", "2026-11-15 13:19", "熊锦豪", "Chrome 157 / 8065", "manual/TC-E04-未登录访问消息中心被拦截.png"),
}

# 用例 → 缺陷双向关联（执行记录页的「缺陷编号」列）
BUG_OF = {
    "TC-B03": "BUG-03",
    "TC-C05": "BUG-06",
    "TC-D03": "BUG-01",
    "TC-D04": "BUG-02",
    "TC-D05": "BUG-04",
}

# 缺陷：编号, 标题, 模块, 严重程度, 优先级, 复现步骤, 实际, 预期, 状态, 禅道ID, 关联用例, 发现来源
BUGS = [
    ("BUG-01", "个人资料修改未校验手机号位数，9 位号码可保存", "个人中心", "中", "中",
     "登录学生端→个人中心→个人资料修改→手机号输入 138001380→点击更新",
     "提示“成功”，9 位手机号被保存", "应校验为 11 位并提示错误、阻止保存", "已关闭", "#75", "TC-D03", "用例执行"),
    ("BUG-02", "个人资料修改未校验年龄范围，121 岁可保存", "个人中心", "中", "中",
     "同上页面→年龄输入 121→点击更新",
     "提示“成功”，数据库年龄变为 121", "应限制 1-120 并提示错误", "已解决", "#76", "TC-D04", "用例执行"),
    ("BUG-03", "未作答直接提交无二次确认，直接交卷记 0 分", "试卷中心与答题", "中", "中",
     "登录→试卷中心→开始答题→不作答→点击提交",
     "无任何提示直接交卷，弹出“试卷得分：0分”", "应提示未作答题目并要求确认交卷", "激活", "#77", "TC-B03", "用例执行"),
    ("BUG-04", "真实姓名留空提交无任何提示，用户无法判断是否保存", "个人中心", "低", "低",
     "个人资料修改→清空真实姓名→点击更新",
     "页面无成功或错误提示，数据未保存", "应提示“真实姓名不能为空”并高亮字段", "激活", "#78", "TC-D05", "用例执行"),
    ("BUG-05", "登录页未做必填前端校验，空用户名直接发起登录请求", "登录注册", "低", "低",
     "打开登录页→用户名留空、密码 123456→点击登录",
     "前端未拦截，直接请求并返回“用户名或密码错误”", "应提示“请输入用户名”，不发起无效请求", "激活", "#79", "—", "探索性测试"),
    ("BUG-06", "考试记录查看不存在的答卷时页面空白并提示“系统内部错误”", "考试记录与错题本", "中", "中",
     "登录学生端→地址栏访问 #/read?id=666666（不存在的答卷 ID）→观察页面",
     "页面停留在加载动画，仅显示“试卷得分：0／试卷耗时：0秒”，内容区空白并提示“系统内部错误”",
     "提示“答卷不存在或无权限查看”，并提供返回考试记录列表的入口", "激活", "#80", "TC-C05", "用例执行"),
]

UI_CHECKS = [
    ("UI-01", "导航", "顶部导航（首页/试卷中心/考试记录/错题本）均可点击并正确跳转", "通过", "compat/UI-01-首页-1366x768.png"),
    ("UI-02", "导航", "浏览器前进/后退可正常在模块间切换，无白屏", "通过", "compat/UI-01-首页-1366x768.png"),
    ("UI-03", "图形", "Logo、头像、二维码、题目配图资源全部加载成功，无裂图", "通过", "compat/UI-01-首页-1366x768.png"),
    ("UI-04", "图形", "主色（蓝）与按钮、选中态配色统一，无错位", "通过", "compat/UI-06-试卷中心表格-1366x768.png"),
    ("UI-05", "内容", "中文文案、题干、选项显示正常，无乱码与截断", "通过", "manual/TC-B02-进入答题页.png"),
    ("UI-06", "内容", "表格列名与数据对齐，分页控件可用", "通过", "compat/UI-06-试卷中心表格-1366x768.png"),
    ("UI-07", "整体界面", "1366×768 窗口下布局完整，无横向滚动条", "通过", "compat/UI-06-试卷中心表格-1366x768.png"),
    ("UI-08", "整体界面", "1536×864 最大化下内容居中、留白合理", "通过", "compat/CP-01-Chrome-1536x864-登录页.png"),

    ("CP-01", "兼容性", "Chrome 157 @1536×864 登录页显示与登录功能正常", "通过", "compat/CP-01-Chrome-1536x864-登录页.png"),
    ("CP-02", "兼容性", "Edge 157 @1536×864 登录页显示与登录功能正常", "通过", "compat/CP-02-Edge-1536x864-登录页.png"),
    ("CP-03", "兼容性", "Chrome 157 @1366×768 登录页布局无错位", "通过", "compat/CP-03-Chrome-1366x768-登录页.png"),
    ("CP-04", "兼容性", "Firefox 160 @1536×864 登录页显示与登录功能正常", "通过", "compat/CP-05-Firefox-登录页.png"),
    ("CP-05", "兼容性", "360 极速浏览器X 23.1 登录页显示与登录功能正常", "通过", "compat/CP-06-360极速浏览器X-登录页.png"),
    ("CP-06", "兼容性", "四款浏览器下试卷中心表格渲染一致，无错行", "通过", "compat/UI-06-试卷中心表格-1366x768.png"),
]

SHOT_DESC = [
    ("TC-A01", "登录页展示", "manual/TC-A01-登录页展示.png", "登录页元素齐全"),
    ("TC-A02", "正确登录进入首页", "manual/TC-A02-正确登录进入首页.png", "跳转 #/index 并展示任务中心"),
    ("TC-A03", "错误密码被拒绝", "manual/TC-A03-错误密码被拒绝.png", "提示“用户名或密码错误”"),
    ("TC-A04", "空用户名被拒绝", "manual/TC-A04-空用户名被拒绝.png", "前端未拦截，服务端返回同一提示"),
    ("TC-A05", "已登录访问登录页", "manual/TC-A05-已登录访问登录页.png", "仍停留登录页"),
    ("TC-B01", "试卷中心列表", "manual/TC-B01-试卷中心列表.png", "固定试卷 1 条"),
    ("TC-B02", "进入答题页", "manual/TC-B02-进入答题页.png", "10 道单选题与倒计时"),
    ("TC-B03", "未作答直接提交", "manual/TC-B03-未作答直接提交.png", "直接弹出 0 分结果"),
    ("TC-B04", "提交后显示得分", "manual/TC-B04-提交后显示得分.png", "试卷得分 50 分"),
    ("TC-B05", "时段试卷空列表", "manual/TC-B05-时段试卷空列表.png", "显示“暂无数据”"),
    ("TC-C01", "考试记录列表", "manual/TC-C01-考试记录列表.png", "3 条记录，状态完成"),
    ("TC-C02", "查看试卷详情", "manual/TC-C02-查看试卷详情.png", "判分 50、正确 10/10"),
    ("TC-C03", "错题本展示", "manual/TC-C03-错题本展示.png", "10 道错题与解析"),
    ("TC-C04", "错题本分页切换", "manual/TC-C04-错题本分页切换.png", "第 2 页剩余 1 条"),
    ("TC-C05", "不存在的答卷报错", "manual/TC-C05-不存在的答卷报错.png", "缺陷 BUG-06 证据：空白页与“系统内部错误”"),
    ("TC-D01", "个人中心信息展示", "manual/TC-D01-个人中心信息展示.png", "资料与用户动态"),
    ("TC-D02", "合法资料保存成功", "manual/TC-D02-合法资料保存成功.png", "提示“成功”，年龄 19"),
    ("TC-D03", "手机号 9 位仍保存", "manual/TC-D03-手机号9位仍保存.png", "缺陷 BUG-01 证据"),
    ("TC-D04", "年龄 121 仍保存", "manual/TC-D04-年龄121仍保存.png", "缺陷 BUG-02 证据"),
    ("TC-D05", "真实姓名留空仍保存", "manual/TC-D05-真实姓名留空仍保存.png", "缺陷 BUG-04 证据"),
    ("TC-E01", "消息中心列表", "manual/TC-E01-消息中心列表.png", "8 条消息与未读状态"),
    ("TC-E02", "消息详情阅读", "manual/TC-E02-消息详情阅读.png", "发送人/时间/内容"),
    ("TC-E03", "未读角标变化", "manual/TC-E03-未读消息阅读后角标变化.png", "角标 6→5"),
    ("TC-E04", "未登录访问被拦截", "manual/TC-E04-未登录访问消息中心被拦截.png", "跳转登录页，未展示消息内容"),
    ("CP-01", "Chrome 1536×864", "compat/CP-01-Chrome-1536x864-登录页.png", "兼容性截图"),
    ("CP-02", "Edge 1536×864", "compat/CP-02-Edge-1536x864-登录页.png", "兼容性截图"),
]


def add_screenshot_sheet(wb):
    ws = wb.create_sheet("截图说明")
    put_head(ws, 1, ["序号", "关联用例", "截图说明", "图片文件", "截图预览"],
             [6, 12, 26, 34, 70])
    r = 2
    for idx, (case, desc, rel, note) in enumerate(SHOT_DESC, 1):
        ws.cell(row=r, column=1, value=idx).alignment = CENTER
        ws.cell(row=r, column=2, value=case).alignment = CENTER
        ws.cell(row=r, column=3, value=desc + "（" + note + "）").alignment = WRAP
        ws.cell(row=r, column=4, value=rel).alignment = WRAP
        path = os.path.join(SHOT, rel.replace("/", os.sep))
        if os.path.exists(path):
            im = PILImage.open(path)
            im.thumbnail((620, 400))
            tmp = os.path.join(ROOT, "target", "shot_%02d.png" % idx)
            os.makedirs(os.path.dirname(tmp), exist_ok=True)
            im.save(tmp)
            img = XLImage(tmp)
            ws.add_image(img, "E%d" % r)
            ws.row_dimensions[r].height = 210
        for c in range(1, 6):
            ws.cell(row=r, column=c).border = BORDER
        r += 1


def main():
    wb = Workbook()

    # 统计口径全部按用例与执行记录自动计算，避免手写数字与数据不一致
    total = len(CASES)
    normal = sum(1 for c in CASES if c[4] == "正常")
    abnormal = total - normal
    passed = sum(1 for c in CASES if EXEC[c[0]][1] == "通过")
    failed = total - passed
    abnormal_pass = sum(1 for c in CASES if c[4] == "异常" and EXEC[c[0]][1] == "通过")
    rate = "%.1f%%" % (passed * 100.0 / total)

    # 缺陷与截图口径同样自动计算，避免手写数字与明细不一致
    bug_mid = sum(1 for b in BUGS if b[3] == "中")
    bug_low = sum(1 for b in BUGS if b[3] == "低")
    bug_from_case = sum(1 for b in BUGS if b[11] == "用例执行")
    bug_from_explore = len(BUGS) - bug_from_case
    func_shots = sum(1 for s in SHOT_DESC if not s[2].startswith("compat/"))
    compat_shots = len(SHOT_DESC) - func_shots
    compat_files = set(os.path.basename(p) for p in glob.glob(os.path.join(SHOT, "compat", "*.png")))
    compat_used = set(os.path.basename(s[2]) for s in SHOT_DESC if s[2].startswith("compat/"))
    compat_extra = len(compat_files - compat_used)

    # ---------- 概述
    ws = wb.active
    ws.title = "概述"
    ws["A1"] = "学之思系统 手工功能测试记录"
    ws["A1"].font = TITLE_FONT
    info = [
        ("被测系统", "学之思在线考试系统 3.9.0（学生端）"),
        ("访问地址", "http://127.0.0.1:8065/student/index.html"),
        ("测试账号", "student / 123456"),
        ("测试环境", "Windows 11 25H2 x64；MySQL 8.0.28 + Redis 5.0.14.1 本地部署"),
        ("测试浏览器", "Chrome 157、Edge 157、Firefox 160、360 极速浏览器X 23.1"),
        ("测试工具", "浏览器 + Excel + 禅道（缺陷管理）+ Apifox/JMeter（见综合报告）"),
        ("测试人员", "熊锦豪（5120245300）"),
        ("测试日期", "2026-11-13 ～ 2026-11-15（13 日执行 22 条，15 日复测补充 2 条）"),
        ("用例总数", "%d 条（正常 %d / 异常 %d）" % (total, normal, abnormal)),
        ("执行结果", "通过 %d 条、失败 %d 条，通过率 %s" % (passed, failed, rate)),
        ("缺陷总数", "%d 个（中 %d / 低 %d），其中 %d 个由失败用例发现、%d 个由探索性测试发现"
         % (len(BUGS), bug_mid, bug_low, bug_from_case, bug_from_explore)),
        ("缺陷管理", "禅道 xiongjh0526.chandao.net 产品“学之思”，BUG #75-#%d" % (74 + len(BUGS))),
        ("截图数量", "功能截图 %d 张、界面与兼容性截图 %d 张（截图说明页共 %d 张内嵌，compat/ 目录另存 %d 张界面与兼容性原图）"
         % (func_shots, compat_shots, len(SHOT_DESC), compat_extra)),
        ("设计方法", "等价类划分、边界值分析、场景法、错误推测法"),
    ]
    r = 3
    for k, v in info:
        ws.cell(row=r, column=1, value=k).font = Font(bold=True)
        ws.cell(row=r, column=2, value=v).alignment = WRAP
        ws.column_dimensions["A"].width = 16
        ws.column_dimensions["B"].width = 96
        r += 1

    # ---------- 测试用例
    ws = wb.create_sheet("测试用例")
    put_head(ws, 1, ["用例编号", "功能模块", "测试标题", "优先级", "用例类型",
                     "前置条件", "测试步骤", "测试数据", "预期结果", "设计方法"],
             [10, 16, 30, 7, 9, 26, 34, 22, 38, 12])
    rows = [(c[0], c[1], c[2], c[3], c[4], c[5], c[6], c[7], c[8], c[9]) for c in CASES]
    fill_rows(ws, 2, rows, center_cols=(1, 4, 5))

    # ---------- 执行记录
    ws = wb.create_sheet("执行记录")
    put_head(ws, 1, ["用例编号", "实际结果", "执行状态", "缺陷编号", "执行时间", "执行人", "测试环境", "截图"],
             [10, 58, 9, 10, 17, 10, 22, 38])
    r = 2
    for c in CASES:
        cid = c[0]
        act, st, tm, who, env, shot = EXEC[cid]
        vals = [cid, act, st, BUG_OF.get(cid, "—"), tm, who, env, shot]
        for i, v in enumerate(vals, 1):
            cell = ws.cell(row=r, column=i, value=v)
            cell.border = BORDER
            cell.alignment = CENTER if i in (1, 3, 4, 5, 6) else WRAP
        ws.cell(row=r, column=3).fill = PASS_FILL if st == "通过" else FAIL_FILL
        r += 1

    # ---------- 缺陷记录
    ws = wb.create_sheet("缺陷记录")
    put_head(ws, 1, ["缺陷编号", "缺陷标题", "所属模块", "严重程度", "优先级",
                     "复现步骤", "实际结果", "预期结果", "状态", "禅道ID", "关联用例", "发现来源"],
             [10, 40, 16, 9, 7, 40, 34, 32, 9, 9, 10, 12])
    fill_rows(ws, 2, BUGS, center_cols=(1, 4, 5, 9, 10, 11, 12))

    # ---------- 统计
    ws = wb.create_sheet("统计")
    put_head(ws, 1, ["统计维度", "分类", "数量", "说明"], [18, 22, 10, 40])
    mod = {}
    for c in CASES:
        mod.setdefault(c[1], [0, 0, 0])
        mod[c[1]][0] += 1
        if EXEC[c[0]][1] == "通过":
            mod[c[1]][1] += 1
        else:
            mod[c[1]][2] += 1
    rows = [("按模块", k, v[0], "通过 %d / 失败 %d" % (v[1], v[2])) for k, v in mod.items()]
    normal_pass = sum(1 for c in CASES if c[4] == "正常" and EXEC[c[0]][1] == "通过")
    rows += [("按类型", "正常场景", normal, "通过 %d / 失败 %d" % (normal_pass, normal - normal_pass)),
             ("按类型", "异常场景", abnormal, "通过 %d / 失败 %d" % (abnormal_pass, abnormal - abnormal_pass)),
             ("总计", "用例总数", total, "通过 %d / 失败 %d，通过率 %s" % (passed, failed, rate))]
    fill_rows(ws, 2, rows, center_cols=(3,))

    # ---------- 界面与兼容性
    ws = wb.create_sheet("界面与兼容性")
    put_head(ws, 1, ["检查编号", "类别", "检查项", "结果", "截图"], [10, 10, 58, 8, 42])
    fill_rows(ws, 2, UI_CHECKS, center_cols=(1, 2, 4))

    add_screenshot_sheet(wb)

    wb.save(OUT)
    print("saved:", OUT)


if __name__ == "__main__":
    main()
