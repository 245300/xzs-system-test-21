/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "10-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "09-复核题目列表"], "isController": false}, {"data": [1.0, 500, 1500, "事务-试卷管理新增试卷"], "isController": true}, {"data": [1.0, 500, 1500, "05-复核学生列表"], "isController": false}, {"data": [1.0, 500, 1500, "08-新增题目"], "isController": false}, {"data": [1.0, 500, 1500, "01-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "06-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "02-查询学生列表"], "isController": false}, {"data": [1.0, 500, 1500, "13-复核试卷列表"], "isController": false}, {"data": [1.0, 500, 1500, "12-新增试卷"], "isController": false}, {"data": [1.0, 500, 1500, "03-新增学生A"], "isController": false}, {"data": [1.0, 500, 1500, "事务-卷题管理新增题目"], "isController": true}, {"data": [1.0, 500, 1500, "04-新增学生B"], "isController": false}, {"data": [1.0, 500, 1500, "事务-用户管理新增学生"], "isController": true}, {"data": [1.0, 500, 1500, "11-查询试卷列表"], "isController": false}, {"data": [1.0, 500, 1500, "07-查询题目列表"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 58, 0, 0.0, 24.568965517241377, 7, 193, 12.0, 44.60000000000001, 191.0, 193.0, 42.151162790697676, 63.14086914062501, 21.08977561773256], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["10-管理员登录", 4, 0, 0.0, 60.75, 12, 191, 20.0, 191.0, 191.0, 191.0, 3.9643211100099105, 2.5609359514370666, 1.5737270812685829], "isController": false}, {"data": ["09-复核题目列表", 3, 0, 0.0, 16.666666666666668, 16, 17, 17.0, 17.0, 17.0, 17.0, 18.75, 56.45751953125, 8.75244140625], "isController": false}, {"data": ["事务-试卷管理新增试卷", 4, 0, 0.0, 112.75, 49, 291, 55.5, 291.0, 291.0, 291.0, 3.663003663003663, 14.566163003663002, 7.8643687042124535], "isController": true}, {"data": ["05-复核学生列表", 6, 0, 0.0, 10.333333333333332, 9, 13, 9.0, 13.0, 13.0, 13.0, 5.4005400540054005, 17.28102497749775, 2.331092484248425], "isController": false}, {"data": ["08-新增题目", 3, 0, 0.0, 26.0, 13, 50, 15.0, 50.0, 50.0, 50.0, 15.544041450777202, 5.601319624352332, 10.570150582901555], "isController": false}, {"data": ["01-管理员登录", 6, 0, 0.0, 42.5, 10, 193, 13.0, 193.0, 193.0, 193.0, 4.480955937266617, 2.8946800317401045, 1.7788169809559373], "isController": false}, {"data": ["06-管理员登录", 3, 0, 0.0, 76.66666666666666, 12, 191, 27.0, 191.0, 191.0, 191.0, 7.772020725388601, 4.928351683937824, 3.162443329015544], "isController": false}, {"data": ["02-查询学生列表", 6, 0, 0.0, 9.0, 8, 11, 8.5, 11.0, 11.0, 11.0, 5.208333333333333, 14.030456542968752, 2.2481282552083335], "isController": false}, {"data": ["13-复核试卷列表", 4, 0, 0.0, 8.25, 7, 9, 8.5, 9.0, 9.0, 9.0, 5.270092226613966, 6.667387187088274, 2.367424242424242], "isController": false}, {"data": ["12-新增试卷", 4, 0, 0.0, 33.75, 18, 77, 20.0, 77.0, 77.0, 77.0, 4.830917874396135, 4.755434782608696, 4.113828502415459], "isController": false}, {"data": ["03-新增学生A", 6, 0, 0.0, 19.5, 9, 44, 12.5, 44.0, 44.0, 44.0, 5.217391304347826, 4.641644021739131, 2.960258152173913], "isController": false}, {"data": ["事务-卷题管理新增题目", 3, 0, 0.0, 141.0, 60, 289, 74.0, 289.0, 289.0, 289.0, 6.237006237006238, 43.786951013513516, 12.601919828482329], "isController": true}, {"data": ["04-新增学生B", 6, 0, 0.0, 10.5, 9, 12, 10.5, 12.0, 12.0, 12.0, 5.3859964093357275, 4.79164328994614, 3.0559217908438057], "isController": false}, {"data": ["事务-用户管理新增学生", 6, 0, 0.0, 91.83333333333334, 45, 269, 58.5, 269.0, 269.0, 269.0, 4.225352112676056, 35.15074823943662, 10.119800836267606], "isController": true}, {"data": ["11-查询试卷列表", 4, 0, 0.0, 10.0, 8, 14, 9.0, 14.0, 14.0, 14.0, 4.866180048661801, 5.260606751824818, 2.1859793187347933], "isController": false}, {"data": ["07-查询题目列表", 3, 0, 0.0, 21.666666666666668, 16, 31, 18.0, 31.0, 31.0, 31.0, 14.423076923076923, 43.48520132211539, 6.732647235576923], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 58, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
