/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "10-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "09-复核题目列表"], "isController": false}, {"data": [1.0, 500, 1500, "事务-试卷管理新增试卷"], "isController": true}, {"data": [1.0, 500, 1500, "08-新增题目"], "isController": false}, {"data": [1.0, 500, 1500, "05-复核学生列表"], "isController": false}, {"data": [1.0, 500, 1500, "06-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "01-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "02-查询学生列表"], "isController": false}, {"data": [1.0, 500, 1500, "13-复核试卷列表"], "isController": false}, {"data": [1.0, 500, 1500, "12-新增试卷"], "isController": false}, {"data": [1.0, 500, 1500, "03-新增学生A"], "isController": false}, {"data": [1.0, 500, 1500, "事务-卷题管理新增题目"], "isController": true}, {"data": [1.0, 500, 1500, "04-新增学生B"], "isController": false}, {"data": [1.0, 500, 1500, "事务-用户管理新增学生"], "isController": true}, {"data": [1.0, 500, 1500, "11-查询试卷列表"], "isController": false}, {"data": [1.0, 500, 1500, "07-查询题目列表"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 58, 0, 0.0, 10.775862068965518, 4, 36, 9.0, 15.0, 36.0, 36.0, 42.64705882352941, 80.80552045036764, 21.279009650735293], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["10-管理员登录", 4, 0, 0.0, 17.0, 9, 36, 11.5, 36.0, 36.0, 36.0, 4.028197381671702, 2.602199773413897, 1.5990842145015105], "isController": false}, {"data": ["09-复核题目列表", 3, 0, 0.0, 13.0, 13, 13, 13.0, 13.0, 13.0, 13.0, 25.423728813559325, 76.79257150423729, 11.86771716101695], "isController": false}, {"data": ["事务-试卷管理新增试卷", 4, 0, 0.0, 46.5, 34, 78, 37.0, 78.0, 78.0, 78.0, 3.7488284910965324, 24.644703315370197, 8.048632263355202], "isController": true}, {"data": ["08-新增题目", 3, 0, 0.0, 12.0, 10, 14, 12.0, 14.0, 14.0, 14.0, 25.64102564102564, 9.239783653846153, 17.553084935897434], "isController": false}, {"data": ["05-复核学生列表", 6, 0, 0.0, 6.5, 5, 9, 6.0, 9.0, 9.0, 9.0, 4.662004662004662, 18.661676864801866, 2.012310606060606], "isController": false}, {"data": ["06-管理员登录", 3, 0, 0.0, 18.666666666666668, 10, 36, 10.0, 36.0, 36.0, 36.0, 20.833333333333332, 13.210720486111112, 8.477105034722223], "isController": false}, {"data": ["01-管理员登录", 6, 0, 0.0, 14.166666666666668, 8, 36, 9.5, 36.0, 36.0, 36.0, 4.518072289156627, 2.918657050075301, 1.793551157756024], "isController": false}, {"data": ["02-查询学生列表", 6, 0, 0.0, 7.0, 5, 11, 6.5, 11.0, 11.0, 11.0, 4.62962962962963, 18.532081886574073, 1.9983362268518519], "isController": false}, {"data": ["13-复核试卷列表", 4, 0, 0.0, 8.25, 4, 17, 6.0, 17.0, 17.0, 17.0, 4.201680672268908, 10.386234571953782, 1.8874737394957983], "isController": false}, {"data": ["12-新增试卷", 4, 0, 0.0, 13.75, 13, 15, 13.5, 15.0, 15.0, 15.0, 4.153686396677051, 4.088785046728972, 3.537123572170301], "isController": false}, {"data": ["03-新增学生A", 6, 0, 0.0, 8.166666666666666, 6, 10, 8.5, 10.0, 10.0, 10.0, 4.647560030983733, 4.09838545701007, 2.6006366189000776], "isController": false}, {"data": ["事务-卷题管理新增题目", 3, 0, 0.0, 57.333333333333336, 48, 74, 50.0, 74.0, 74.0, 74.0, 12.987012987012989, 91.36989312770562, 26.299546807359306], "isController": true}, {"data": ["04-新增学生B", 6, 0, 0.0, 8.666666666666668, 6, 12, 8.5, 12.0, 12.0, 12.0, 4.643962848297213, 4.095213332043343, 2.5986237422600618], "isController": false}, {"data": ["事务-用户管理新增学生", 6, 0, 0.0, 44.5, 34, 74, 39.5, 74.0, 74.0, 74.0, 4.2674253200568995, 44.44748510846373, 10.153888469061167], "isController": true}, {"data": ["11-查询试卷列表", 4, 0, 0.0, 7.5, 5, 10, 7.5, 10.0, 10.0, 10.0, 4.162330905306972, 10.287948751300728, 1.8697970863683664], "isController": false}, {"data": ["07-查询题目列表", 3, 0, 0.0, 13.666666666666666, 13, 15, 13.0, 15.0, 15.0, 15.0, 24.793388429752067, 74.88862345041322, 11.573476239669422], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 58, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
