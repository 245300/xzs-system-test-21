/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "10-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "09-复核题目列表"], "isController": false}, {"data": [1.0, 500, 1500, "事务-试卷管理新增试卷"], "isController": true}, {"data": [1.0, 500, 1500, "05-复核学生列表"], "isController": false}, {"data": [1.0, 500, 1500, "08-新增题目"], "isController": false}, {"data": [1.0, 500, 1500, "01-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "06-管理员登录"], "isController": false}, {"data": [1.0, 500, 1500, "02-查询学生列表"], "isController": false}, {"data": [1.0, 500, 1500, "13-复核试卷列表"], "isController": false}, {"data": [1.0, 500, 1500, "12-新增试卷"], "isController": false}, {"data": [1.0, 500, 1500, "03-新增学生A"], "isController": false}, {"data": [1.0, 500, 1500, "事务-卷题管理新增题目"], "isController": true}, {"data": [1.0, 500, 1500, "04-新增学生B"], "isController": false}, {"data": [1.0, 500, 1500, "事务-用户管理新增学生"], "isController": true}, {"data": [1.0, 500, 1500, "11-查询试卷列表"], "isController": false}, {"data": [1.0, 500, 1500, "07-查询题目列表"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 58, 0, 0.0, 26.862068965517224, 9, 141, 16.0, 56.60000000000001, 86.34999999999992, 141.0, 41.42857142857142, 78.85463169642857, 20.728236607142858], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["10-管理员登录", 4, 0, 0.0, 28.75, 13, 45, 28.5, 45.0, 45.0, 45.0, 3.7842951750236518, 2.444639900662252, 1.5022617076631979], "isController": false}, {"data": ["09-复核题目列表", 3, 0, 0.0, 64.66666666666666, 24, 141, 29.0, 141.0, 141.0, 141.0, 7.092198581560283, 21.209644651300238, 3.3106161347517733], "isController": false}, {"data": ["事务-试卷管理新增试卷", 4, 0, 0.0, 112.75, 66, 198, 93.5, 198.0, 198.0, 198.0, 3.3869602032176123, 22.104545935647756, 7.271710944115156], "isController": true}, {"data": ["05-复核学生列表", 6, 0, 0.0, 15.166666666666666, 9, 21, 14.5, 21.0, 21.0, 21.0, 4.6875, 19.08111572265625, 2.0233154296875], "isController": false}, {"data": ["08-新增题目", 3, 0, 0.0, 54.333333333333336, 16, 85, 62.0, 85.0, 85.0, 85.0, 8.720930232558139, 3.142600835755814, 5.930346111918605], "isController": false}, {"data": ["01-管理员登录", 6, 0, 0.0, 18.666666666666664, 10, 44, 14.0, 44.0, 44.0, 44.0, 4.428044280442804, 2.860499308118081, 1.7578125], "isController": false}, {"data": ["06-管理员登录", 3, 0, 0.0, 24.0, 13, 44, 15.0, 44.0, 44.0, 44.0, 10.238907849829351, 6.492640784982935, 4.166222269624574], "isController": false}, {"data": ["02-查询学生列表", 6, 0, 0.0, 28.0, 11, 75, 18.5, 75.0, 75.0, 75.0, 4.545454545454545, 18.46590909090909, 1.9620028409090908], "isController": false}, {"data": ["13-复核试卷列表", 4, 0, 0.0, 13.5, 10, 15, 14.5, 15.0, 15.0, 15.0, 4.206098843322818, 10.40229035226078, 1.8894584647739223], "isController": false}, {"data": ["12-新增试卷", 4, 0, 0.0, 46.75, 19, 112, 28.0, 112.0, 112.0, 112.0, 3.7986704653371324, 3.7393162393162394, 3.2348053181386516], "isController": false}, {"data": ["03-新增学生A", 6, 0, 0.0, 16.166666666666664, 10, 34, 13.0, 34.0, 34.0, 34.0, 4.583651642475172, 4.077838521772345, 2.6006851604278074], "isController": false}, {"data": ["事务-卷题管理新增题目", 3, 0, 0.0, 187.66666666666666, 90, 295, 178.0, 295.0, 295.0, 295.0, 4.838709677419355, 33.774886592741936, 9.776650705645162], "isController": true}, {"data": ["04-新增学生B", 6, 0, 0.0, 12.666666666666668, 11, 15, 12.5, 15.0, 15.0, 15.0, 4.665629860031105, 4.150770314930015, 2.647198192068429], "isController": false}, {"data": ["事务-用户管理新增学生", 6, 0, 0.0, 90.66666666666667, 52, 133, 81.5, 133.0, 133.0, 133.0, 4.160887656033287, 43.932445171636616, 9.965407203536754], "isController": true}, {"data": ["11-查询试卷列表", 4, 0, 0.0, 23.75, 13, 40, 21.0, 40.0, 40.0, 40.0, 3.8095238095238093, 9.229910714285714, 1.7113095238095237], "isController": false}, {"data": ["07-查询题目列表", 3, 0, 0.0, 44.666666666666664, 35, 56, 43.0, 56.0, 56.0, 56.0, 9.933774834437086, 29.752819743377483, 4.6370550496688745], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 58, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
